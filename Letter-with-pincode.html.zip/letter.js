/* second click: fully slide letter up */
.envelope.full-open .letter {
  top: -200px; /* higher pop-up than before */
  opacity: 1;
  z-index: 4;
  box-shadow: 0 8px 20px rgba(0,0,0,0.3);
}
