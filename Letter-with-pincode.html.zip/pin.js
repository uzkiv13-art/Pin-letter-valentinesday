const correctPin = "11202025"; // Your pin
const button = document.getElementById('unlockBtn');
const pinInput = document.getElementById('pin');
const message = document.getElementById('message');

button.addEventListener('click', () => {
  const userPin = pinInput.value.trim();

  if(userPin === correctPin) {
    message.innerHTML = "Yay! 💌 Redirecting...";
    setTimeout(() => {
      window.location.href = "valentinesletter.html"; // Redirect to your letter
    }, 1000);
  } else {
    message.innerHTML = `
      <p>Are you really my baby? 😢</p>
      <img src="https://media.tenor.com/6OsmtdbJMYAAAAAC/crying-cat.gif" 
           alt="Crying cat" style="width:150px; margin-top:10px;">
    `;
    pinInput.value = "";    // Clear the input
    pinInput.focus();       // Put focus back to input so user can type again
  }
});
